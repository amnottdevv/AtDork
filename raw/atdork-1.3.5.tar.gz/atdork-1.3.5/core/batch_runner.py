"""
Atdork - Batch Query Runner (Enhanced with Case Modules)
Menjalankan banyak dork sekaligus dengan progress bar, retry cerdas,
adaptive delay, fallback manager, circuit breaker, dan concurrency.
"""

import logging
from concurrent.futures import ThreadPoolExecutor, as_completed
from typing import List, Dict, Optional

from rich.progress import (
    Progress,
    SpinnerColumn,
    TextColumn,
    BarColumn,
    TimeElapsedColumn,
)

from core.scanner import search_dork
from core.case.error_classifier import classify_error, ErrorCategory
from core.case.retry_handler import RetryHandler
from core.case.adaptive_delay import AdaptiveDelay
from core.case.fallback_manager import FallbackManager, FallbackAction
from core.case.circuit_breaker import CircuitBreaker

logger = logging.getLogger(__name__)


def load_queries_from_file(filepath: str) -> List[str]:
    queries = []
    with open(filepath, "r", encoding="utf-8") as f:
        for line in f:
            line = line.strip()
            if not line or line.startswith("#"):
                continue
            queries.append(line)
    return queries


def parse_query_string(query_str: str, separator: str = ";") -> List[str]:
    return [q.strip() for q in query_str.split(separator) if q.strip()]


def run_batch(
    queries: List[str],
    case_modules: Optional[Dict] = None,
    concurrency: int = 1,
    **search_kwargs,
) -> Dict[str, list]:
    """
    Jalankan pencarian untuk setiap query dengan dukungan modul case.

    Args:
        queries: Daftar query.
        case_modules: Dictionary berisi instance modul case (lihat _setup_case_modules).
        concurrency: Jumlah thread paralel.
        **search_kwargs: Parameter untuk search_dork.

    Returns:
        Dictionary {query: [list of result dicts]}.
    """
    results = {}
    total = len(queries)
    if total == 0:
        return results

    # Ambil modul case jika tersedia
    circuit_breaker = None
    fallback_manager = None
    retry_handler = None
    adaptive_delay = None

    if case_modules:
        circuit_breaker = case_modules.get("circuit_breaker")
        fallback_manager = case_modules.get("fallback_manager")
        retry_handler = case_modules.get("retry_handler")
        adaptive_delay = case_modules.get("adaptive_delay")

    # Jika tidak ada retry_handler, buat default sederhana
    if retry_handler is None:
        retry_handler = RetryHandler(max_retries=2, base_delay=1.0)

    def _execute_single(q: str) -> list:
        """
        Eksekusi satu query dengan retry, adaptive delay, dan fallback.
        """
        backend = search_kwargs.get("backend", "auto")
        current_backend = backend
        current_proxy = None

        # Proxy diambil dari search_kwargs['proxy_manager'] jika ada
        proxy_manager = search_kwargs.get("proxy_manager")
        if proxy_manager:
            try:
                current_proxy = proxy_manager.get_proxy()
            except Exception:
                current_proxy = None

        # Adaptive delay
        if adaptive_delay:
            adaptive_delay.wait(current_backend)

        # Fungsi yang akan di-retry
        def _do_search():
            return search_dork(q, backend=current_backend, **search_kwargs)

        # Callback saat retry
        def _on_retry(attempt, exception):
            nonlocal current_backend, current_proxy
            category = classify_error(exception)
            logger.debug("Retry attempt %d setelah error %s: %s", attempt, category, exception)

            # Jika ada fallback manager, minta keputusan
            if fallback_manager and circuit_breaker:
                decision = fallback_manager.decide(
                    current_backend=current_backend,
                    current_proxy=current_proxy,
                    error_category=category,
                )
                action = decision.get("action")
                if action == FallbackAction.SWITCH_BACKEND:
                    new_backend = decision.get("next_backend", current_backend)
                    logger.info("Fallback: ganti backend %s → %s", current_backend, new_backend)
                    current_backend = new_backend
                elif action == FallbackAction.ROTATE_PROXY:
                    new_proxy = decision.get("next_proxy")
                    if new_proxy and proxy_manager:
                        # Update proxy di search_kwargs? Tidak bisa langsung,
                        # tapi kita bisa set proxy_manager.get_proxy() untuk return proxy tertentu.
                        # Untuk sederhana, kita biarkan proxy_manager mengelola rotasi.
                        pass
                elif action == FallbackAction.COOLDOWN:
                    logger.info("Fallback: cooldown, jeda 30 detik")
                    import time
                    time.sleep(30)
                elif action == FallbackAction.ABORT:
                    logger.error("Fallback: abort, tidak bisa melanjutkan")
                    raise exception

            # Jika adaptive delay, laporkan error
            if adaptive_delay:
                status_code = 429 if "429" in str(exception) else 500
                adaptive_delay.report(current_backend, status_code, False)

        # Callback saat menyerah
        def _on_giveup(exception):
            if adaptive_delay:
                adaptive_delay.report(current_backend, 500, False)

        try:
            # Jalankan dengan retry handler
            result, final_error = retry_handler.execute(
                _do_search,
                on_retry=_on_retry,
                on_giveup=_on_giveup,
            )

            if final_error:
                logger.error("'%s' gagal setelah retry: %s", q[:60], final_error)
                return []

            # Sukses, laporkan ke adaptive delay
            if adaptive_delay:
                adaptive_delay.report(current_backend, 200, len(result) > 0)
            # Catat keberhasilan di circuit breaker
            if circuit_breaker:
                circuit_breaker.record_success(current_backend)
                if current_proxy:
                    circuit_breaker.record_success(current_proxy)

            return result

        except Exception as e:
            logger.error("'%s' gagal tak terduga: %s", q[:60], e)
            return []

    with Progress(
        SpinnerColumn(),
        TextColumn("[progress.description]{task.description}"),
        BarColumn(),
        TextColumn("[progress.percentage]{task.percentage:>3.0f}%"),
        TimeElapsedColumn(),
    ) as progress:
        task = progress.add_task("[cyan]Running batch queries...", total=total)

        if concurrency > 1:
            with ThreadPoolExecutor(max_workers=concurrency) as executor:
                future_to_query = {
                    executor.submit(_execute_single, q): q for q in queries
                }
                for future in as_completed(future_to_query):
                    q = future_to_query[future]
                    try:
                        res = future.result()
                    except Exception as e:
                        logger.error("'%s' failed unexpectedly: %s", q[:60], e)
                        res = []
                    results[q] = res
                    progress.update(task, advance=1)
        else:
            for idx, q in enumerate(queries, 1):
                desc = q if len(q) <= 60 else q[:57] + "..."
                progress.update(task, description=f"[{idx}/{total}] {desc}")
                res = _execute_single(q)
                results[q] = res
                progress.advance(task)

    return results